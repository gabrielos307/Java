import javax.swing.JFrame;{

public class Hola extends JFrame{
	public Hola(String title){
		super(title);
		
		setSize(400,600);
		setVisible(true);
	}
}
