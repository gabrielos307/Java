public class TestEjemploFile{
	public static void main(String[] args){
		EjemploFile archivo = new EjemploFile("./");
	}
}
