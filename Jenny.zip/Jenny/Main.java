public Main(){
	public static void main(String args[]){
		new JFrame("Ventana 1").setVisible(true);
		new Hola("Ventana 2");
	}
}
